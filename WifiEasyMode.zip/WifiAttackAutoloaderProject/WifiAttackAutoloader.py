# coding=UTF-8

import os
import socket
import operator
from termcolor import colored
import sys
sys.stdout.write("\x1b[8;{rows};{cols}t".format(rows=64, cols=200)) # sets window to full screen

os.system('cat /root/WifiAttackAutoloaderProject/DISCLAIMER')

def mana_toolkit():
    opt_List = [
        '\n\t#INSTALL. Install Mana-Toolkit Prerequisites',
        '#1. Configure start-nat-full, change which hostapd file to use, etc.',
        '#2. Configure the Mana-Tookit Settings (hostapd file), Change BSSID Name, MAC Address, etc',
        '#3. Start the Mana Man-In-The-Middle Attack',
        '#999. Restart All Network Interfaces (If there is something wrong with wifi card detection in Mana)'
        '#0. Return to the Main Menu'
    ]
    print ("\n\t".join(opt_List))
    opt_Choice = str(raw_input("Enter a OPTION: "))
        #Sample open new terminal window code from other projects
        #os.system("gnome-terminal -e 'bash -c \"python /root/ArmsCommander/IDS_flood.py; exec bash\"'")

    if opt_Choice == "INSTALL":
        os.system('clear')
        os.system("gnome-terminal -e 'bash -c \"python /root/WifiAttackAutoloaderProject/Mana_Installer.py; exec bash\"'")
        mana_toolkit()
    elif opt_Choice == "1":
        os.system("gnome-terminal -e 'bash -c \"nano /usr/share/mana-toolkit/run-mana/start-nat-full.sh; exec bash\"'")
    elif opt_Choice == "2":
        os.system("gnome-terminal -e 'bash -c \"nano /etc/mana-toolkit/hostapd-mana.conf\"'")
    elif opt_Choice == "3":
        print colored('Starting Mana','red','on_white')
        os.system('/usr/share/mana-toolkit/run-mana/start-nat-full.sh')
    elif opt_Choice == "999":
        os.system('/root/WifiAttackAutoloaderProject/bring_Interfaces_Down.sh')
        os.system('/root/WifiAttackAutoloaderProject/bring_Interfaces_Up.sh')
        main()
    elif opt_Choice == "0":
        main()
    else:
        print colored('You have entered a invalid option','red','on_white')
        mana_toolkit()


def fern_wifi_cracker():
    opt_List = [
        '\n\t#1. Install Fern-Wifi-cracker Prequisites',
        '#2. Start Fern-Wifi-Cracker',
        '#0. Return to the Main Menu'
    ]

    print ("\n\t".join(opt_List))
    opt_Choice = str(raw_input("Enter a OPTION: "))

    if opt_Choice == "1":
        os.system('sudo apt-get update')
        os.system('sudo apt-get install fern-wifi-cracker')
        fern_wifi_cracker()
    elif opt_Choice == "2":
        os.system('fern-wifi-cracker')
def aircrack_suite():
    print colored('This section has not yet been implemented yet, for the most part, many of aircrack abilities can be done via Fern-Wifi-Cracker','red','on_white')


def main():
    print colored('MAIN MENU','red','on_white')
    opt_List = [
        '\n\t#1. Run Mana-Toolkit "Evil Twin" MitM Attacks',
        '#2. Run the Fern-Wifi-Cracker Suite',
        '#3. Run the Aircrack Suite'
    ]

    print ("\n\t".join(opt_List))

    opt_Choice = str(raw_input("Enter a OPTION: "))

    if opt_Choice == "1":
        os.system('clear')
        mana_toolkit()
    elif opt_Choice == "2":
        os.system('clear')
        fern_wifi_cracker()
    elif opt_Choice == "3":
        os.system('clear')
        aircrack_suite()
    else:
        print colored('You have entered a invalid option','red','on_white')
        main()

main()
