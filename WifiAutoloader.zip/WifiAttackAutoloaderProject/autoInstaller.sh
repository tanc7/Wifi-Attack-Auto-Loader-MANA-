chmod 777 ./WifiAttackAutoloader.py
mkdir /root/WifiAttackAutoloaderProject
cp -r ./WifiAttackAutoloader.py /usr/local/bin
cp -r ./ /root/WifiAttackAutoloaderProject
echo  Installation complete
echo type WifiAttackAutoloader.py to launch
