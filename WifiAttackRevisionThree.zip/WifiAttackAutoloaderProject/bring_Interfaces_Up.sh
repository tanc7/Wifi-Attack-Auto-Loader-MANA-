rfkill unblock all
rfkill list all
ifconfig wlan0 up
ifconfig wlan1 up
ifconfig eth0 up
#service network-manager restart
