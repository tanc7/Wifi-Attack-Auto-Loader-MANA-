***Kali Linux Installation***

1. Unzip the contents of the file, including the Folder /WifiAttackAutoloaderProject into your /root directory
2. Open a terminal and type...

"python /root/WifiAttackAutoloaderProject/WifiAttackAutoloader.py"

3. You should run the installation scripts for Mana-Toolkit first, and then change your network manager to Wicd

Make sure you have a compatible cheapo External Wireless Card with the ability to...

1. ARP Injection
2.

which you can Google it and buy it on Amazon.

Failure to buy one for only like, $13 or so, means that the full capabilities of these wireless attack tools may be buggy or limited in function
